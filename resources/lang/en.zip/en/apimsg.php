<?php

  return [
        "You have a new upcoming appointment" =>"You have a new upcoming appointment!",
        "Your Appointment  has been accept by"=>"Your Appointment  has been accept by",
        "for time"=>"for time",
        "Your Appointment  has been reject By"=>"Your Appointment  has been reject By",
        "Your Appointment  with"=>"Your Appointment with",
        "You were absent on your appointment with"=>"You were absent on your appointment with"
      
      ];