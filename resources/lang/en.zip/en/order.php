<?php

return [


    'newappointment' => 'You have a new upcoming appointment!',
    'inprocess1'=>"Your Appointment  has been accept by",
    'inprocess2' => 'for time',
    "rejectorder"=>'Your Appointment  has been reject By',
    "complete1"=>"Your Appointment  with",
    "complete2"=>"is completed"

];
